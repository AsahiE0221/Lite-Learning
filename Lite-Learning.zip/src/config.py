"""路径和全局配置管理。

为跨用户分发设计：
- ~/.lite-learning/  全局配置、API key、命令历史（用户专属）
- ./papers/ ./notes/ 工作数据（跟随当前目录）
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# ── 用户全局目录 ──
GLOBAL_DIR = Path.home() / ".lite-learning"
GLOBAL_DIR.mkdir(parents=True, exist_ok=True)

# 加载 .env：优先 ~/.lite-learning/.env，回退到当前目录
global_env = GLOBAL_DIR / ".env"
# 统一从 ~/.lite-learning/.env 加载配置
if global_env.exists():
    load_dotenv(global_env)

# ── 工作目录 ──
# LIT_DEV=1 时使用项目根目录（开发用），否则使用 pwd
if os.getenv("LIT_DEV") == "1":
    WORK_DIR = Path(__file__).resolve().parent.parent
else:
    WORK_DIR = Path.cwd()

PAPERS_DIR = WORK_DIR / "papers"
NOTES_DIR = WORK_DIR / "notes"
HISTORY_FILE = GLOBAL_DIR / ".history"


def ensure_dirs():
    PAPERS_DIR.mkdir(exist_ok=True)
    NOTES_DIR.mkdir(exist_ok=True)
