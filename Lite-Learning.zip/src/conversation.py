"""论文对话：问答、自由聊天、摘要、笔记生成。"""
import os
from datetime import datetime
from llm.client import chat, chat_stream
from prompts import SYSTEM_PROMPT, SUMMARY_TASK, NOTE_TASK


def _build_user_content(paper_title: str, paper_text: str, question: str,
                         task_instruction: str | None, mode_label: str) -> str:
    """拼装 user message：模式标记 + 论文上下文 + 任务指令 + 用户问题。"""
    parts = [f"【当前模式：{mode_label}】"]
    parts.append(f"【论文标题】{paper_title}")
    parts.append(f"【论文全文】{paper_text}")
    if task_instruction:
        parts.append(f"【任务指令】{task_instruction}")
    parts.append(f"【用户问题】{question}")
    return "\n".join(parts)


def ask(question: str, session, task_instruction: str | None = None) -> str:
    """同步问答（用于 ReAct handler）。"""
    if not session.is_paper_loaded():
        return "请先加载论文。"

    user_content = _build_user_content(
        session.paper_title, session.paper_text, question,
        task_instruction, session.mode_label,
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        *session.history,
        {"role": "user", "content": user_content},
    ]

    reply = chat(messages)
    session.history.append({"role": "user", "content": user_content})
    session.history.append({"role": "assistant", "content": reply})
    session.total_rounds += 1
    return reply


def ask_stream(question: str, session, task_instruction: str | None = None):
    """流式问答。"""
    if not session.is_paper_loaded():
        yield "请先加载论文。"
        return

    user_content = _build_user_content(
        session.paper_title, session.paper_text, question,
        task_instruction, session.mode_label,
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        *session.history,
        {"role": "user", "content": user_content},
    ]

    full_reply = ""
    for chunk in chat_stream(messages):
        full_reply += chunk
        yield chunk

    session.history.append({"role": "user", "content": user_content})
    session.history.append({"role": "assistant", "content": full_reply})
    session.total_rounds += 1


def free_chat(user_input: str, session):
    """自由对话：有论文带论文上下文，无论文纯闲聊。"""
    if session.is_paper_loaded():
        yield from ask_stream(user_input, session)
    else:
        session.chat_history.append({"role": "user", "content": user_input})

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            *session.chat_history,
        ]

        full_reply = ""
        for chunk in chat_stream(messages):
            full_reply += chunk
            yield chunk

        session.chat_history.append({"role": "assistant", "content": full_reply})


def summary_stream(extra_requirement: str | None, session):
    """生成结构化摘要。"""
    question = "请生成论文摘要"
    task = SUMMARY_TASK
    if extra_requirement:
        task += f" 额外要求：{extra_requirement}"
    yield from ask_stream(question, session, task_instruction=task)


def write_note(session) -> str:
    """生成结构化阅读笔记并保存到 notes/ 目录。"""
    if not session.is_paper_loaded():
        return "请先加载论文。"

    note_content = ask(
        question="请基于论文和讨论内容生成阅读笔记",
        session=session,
        task_instruction=NOTE_TASK,
    )

    os.makedirs(session.notes_dir, exist_ok=True)
    safe_title = session.paper_title.replace("/", "_").replace(" ", "_")
    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"{safe_title}-{date_str}.md"
    filepath = os.path.join(session.notes_dir, filename)

    try:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# {session.paper_title}\n\n")
            f.write(f"笔记撰写日期: {date_str}\n")
            f.write(f"论文页数: {session.paper_pages}\n\n")
            f.write(note_content)
        return f"✅ 笔记已保存: {filepath}"
    except Exception as e:
        return f"笔记保存失败: {e}"


def write_note_stream(session):
    """流式生成阅读笔记并保存。"""
    if not session.is_paper_loaded():
        yield "请先加载论文。"
        return

    os.makedirs(session.notes_dir, exist_ok=True)
    safe_title = session.paper_title.replace("/", "_").replace(" ", "_")
    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"{safe_title}-{date_str}.md"
    filepath = os.path.join(session.notes_dir, filename)

    # 流式生成笔记内容
    full_content = ""
    for chunk in ask_stream(
        question="请基于论文和讨论内容生成阅读笔记",
        session=session,
        task_instruction=NOTE_TASK,
    ):
        full_content += chunk
        yield chunk

    # 保存
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# {session.paper_title}\n\n")
            f.write(f"笔记撰写日期: {date_str}\n")
            f.write(f"论文页数: {session.paper_pages}\n\n")
            f.write(full_content)
        yield f"\n\n✅ 笔记已保存: {filepath}"
    except Exception as e:
        yield f"\n\n笔记保存失败: {e}"
