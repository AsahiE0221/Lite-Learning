"""Shell 命令安全分级模块。

返回值:
  "safe"      — 直接执行（纯读操作）
  "confirm"   — 需用户确认（写/改/网络操作）
  "forbidden" — 绝对禁止
"""

import re
import shlex

# ── 高危正则模式 ──
FORBIDDEN_PATTERNS = [
    # 管道到 shell 执行（远程代码注入）
    r'curl.*\|\s*(?:ba)?sh',
    r'wget.*\|\s*(?:ba)?sh',

    # 写入磁盘设备
    r'>\s*/dev/sd[a-z]',
    r'>\s*/dev/disk\d',
    r'dd\s+.*of=/dev/(?!null|zero|random|urandom)',  # dd 写入非安全设备

    # Fork 炸弹
    r':\(\)\s*\{.*:\|:.*\};?\s*:',

    # find 执行任意命令
    r'find\s+.*-exec\b',
    r'find\s+.*-execdir\b',

    # 输出重定向到敏感路径
    r'>>?\s*/etc/',
    r'>>?\s*~/\.',
    r'>>?\s*\$HOME',
    r'>>?\s*\$\{HOME\}',

    # eval / exec 任意代码执行
    r'\beval\b',
    r'\bexec\b',

    # 递归删除关键目录（放宽空格匹配）
    r'rm\s+.*-r[fv]*\s+/(?:\s|$)',  # rm -rf / (允许任意空格)
    r'rm\s+.*-r[fv]*\s+~\s*',       # rm -rf ~
    r'rm\s+.*-r[fv]*\s+\.\*',       # rm -rf .*
    r'rm\s+.*-r[fv]*\s+/\*',        # rm -rf /*
    r'rm\s+.*-r[fv]*\s+\$HOME',     # rm -rf $HOME
    r'rm\s+.*-r[fv]*\s+/home/',     # rm -rf /home/...

    # 极端权限
    r'chmod\s+.*[-\s]*[rR]\s+/\s*',                     # chmod -R /
    r'chmod\s+.*(?:777|000|o\+w|ugo\+w|a\+w)',          # chmod 777/000

    # nc/wget/curl 反弹 shell 特征
    r'nc\s+.*-[ec]',               # nc -e /bin/sh
    r'nc\s+.*-[lL].*-[ec]',        # nc -l -e /bin/sh

    # 命令替换（反引号或 $()）— 高危，无法预知内容
    r'`[^`]+`',
    r'\$\([^)]+\)',
]

# ── 命令连接符/分隔符正则 ──
# 这四种符号可以在一条命令里串联多条命令
CHAIN_PATTERN = re.compile(r'[;&|]{1,2}(?=\s*\S)')

# ── 绝对禁止的主命令 ──
FORBIDDEN_COMMANDS = {
    "sudo",
    "mkfs", "fdisk", "fsck",
    "shutdown", "reboot", "halt", "poweroff",
    "chroot", "mount", "umount",
    "iptables", "ufw", "pfctl",
    "passwd", "dscl", "visudo",
}

# ── 需确认的主命令 ──
CONFIRM_COMMANDS = {
    "rm",
    "mv",
    "cp",
    "touch",
    "mkdir",
    "rmdir",
    "chmod",
    "chown",
    "chgrp",
    "ln",
    "export",
    "alias",
    "unset",
    "kill",
    "killall",
    "pkill",
    "renice",
    "ssh",
    "telnet",
    "scp",
    "rsync",
    "curl",
    "wget",
    "tar",
    "unzip",
    "gunzip",
    "zip",
    "gzip",
    "bzip2",
    "make",
    "gcc",
    "g++",
    "cmake",
    "tee",
    "sed",
    "systemctl",
    "launchctl",
    "service",
    "defaults",
    "pip3",
    "pip",
    "npm",
    "npx",
    "yarn",
    "pnpm",
    "brew",
    "apt",
    "apt-get",
    "yum",
    "dnf",
    "pacman",
    "git",
    "crontab",
    "docker",
    "podman",
    "dd",
    "nc",
    "python",
    "python3",
    "node",
    "awk",
    "sh",
    "bash",
    "zsh",
    "dash",
    "perl",
    "ruby",
}

# ── 安全读命令 ──
SAFE_COMMANDS = {
    "ls",
    "ll",
    "dir",
    "pwd",
    "whoami",
    "id",
    "hostname",
    "cat",
    "head",
    "tail",
    "less",
    "more",
    "wc",
    "du",
    "df",
    "file",
    "stat",
    "find",
    "locate",
    "which",
    "whereis",
    "type",
    "grep",
    "egrep",
    "echo",
    "printf",
    "date",
    "cal",
    "uptime",
    "ps",
    "top",
    "htop",
    "pgrep",
    "env",
    "printenv",
    "uname",
    "arch",
    "man",
    "help",
    "sort",
    "uniq",
    "cut",
    "tr",
    "paste",
    "basename",
    "dirname",
    "realpath",
    "readlink",
    "tree",
}

# ── 子命令规则 ──
SUBCOMMAND_RULES = {
    "git": {
        "safe": {"status", "log", "diff", "branch", "show", "remote", "stash list"},
        "confirm": {"add", "commit", "push", "pull", "merge", "rebase", "checkout",
                    "clone", "reset", "stash", "tag", "config", "clean", "fetch"},
        "forbidden": {"push --force", "reset --hard"},
    },
    "pip": {
        "safe": {"list", "show", "freeze", "--version", "config list"},
        "confirm": {"install", "uninstall", "download", "wheel", "cache"},
    },
    "pip3": {
        "safe": {"list", "show", "freeze", "--version", "config list"},
        "confirm": {"install", "uninstall", "download", "wheel", "cache"},
    },
    "npm": {
        "safe": {"list", "ls", "view", "outdated", "--version", "config list"},
        "confirm": {"install", "uninstall", "update", "publish", "audit fix",
                    "init", "link", "adduser", "login", "logout"},
    },
    "npx": {
        "safe": set(),
        "confirm": set(),
    },
    "brew": {
        "safe": {"list", "ls", "info", "search", "outdated", "--version", "config"},
        "confirm": {"install", "uninstall", "upgrade", "update", "cleanup",
                    "doctor", "link", "unlink", "services"},
    },
    "apt": {
        "safe": {"list", "search", "show", "policy", "info", "--version"},
        "confirm": {"install", "remove", "purge", "update", "upgrade",
                    "autoremove", "autoclean", "full-upgrade", "dist-upgrade"},
    },
    "apt-get": {
        "safe": {"--version"},
        "confirm": {"install", "remove", "purge", "update", "upgrade",
                    "autoremove", "autoclean", "dist-upgrade", "check"},
    },
    "yum": {
        "safe": {"list", "info", "search", "check-update", "--version"},
        "confirm": {"install", "remove", "update", "upgrade", "clean", "erase"},
    },
    "dnf": {
        "safe": {"list", "info", "search", "check-update", "--version", "repoquery"},
        "confirm": {"install", "remove", "update", "upgrade", "clean", "erase"},
    },
    "pacman": {
        "safe": {"-Q", "-Qi", "-Qs", "-Si", "-Ss", "--version"},
        "confirm": {"-S", "-R", "-U", "-Sy", "-Syu", "-Rns"},
    },
    "docker": {
        "safe": {"ps", "images", "logs", "inspect", "stats", "version", "info"},
        "confirm": {"run", "build", "start", "stop", "rm", "rmi", "pull", "push",
                    "exec", "compose"},
    },
    "systemctl": {
        "safe": {"status", "list-units", "list-timers", "is-enabled", "show"},
        "confirm": {"start", "stop", "restart", "enable", "disable", "reload",
                    "mask", "unmask"},
    },
    "crontab": {
        "safe": {"-l"},
        "confirm": {"-e"},
        "forbidden": {"-r"},
    },
    "dd": {
        "safe": set(),
        "confirm": set(),
        # dd 默认 confirm，仅当 of= 指向安全设备时才允许
    },
    "nc": {
        "safe": set(),
        "confirm": set(),
        "forbidden": {"-e", "-c"},
    },
}


def _has_command_chaining(command: str) -> bool:
    """检测命令中是否含有 ; && || | 等连接多条命令的符号。"""
    return bool(CHAIN_PATTERN.search(command))


def _extract_main_command(command: str) -> str:
    """从命令字符串中提取主命令名。"""
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()
    if not tokens:
        return ""
    main = tokens[0]
    if "/" in main:
        main = main.rsplit("/", 1)[-1]
    return main


def _get_subcommand(command: str) -> str | None:
    """提取子命令。对于在 SUBCOMMAND_RULES 中注册的命令，将第一个非主命令的 token 作为子命令。"""
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()

    main = tokens[0] if tokens else ""
    if "/" in main:
        main = main.rsplit("/", 1)[-1]

    # 对于有子命令规则注册的命令，不跳过任何 token
    if main in SUBCOMMAND_RULES:
        for t in tokens[1:]:
            # 跳过已知的子命令修饰符（如 --force）
            if t.startswith("--") and len(t) > 2:
                continue
            return t
        return None

    # 通用逻辑：跳过 flag，找第一个非 flag 参数
    for t in tokens[1:]:
        if t.startswith("-"):
            continue
        return t
    return None


def _check_subcommand(main_cmd: str, sub: str | None) -> str | None:
    """根据子命令规则检查安全性。"""
    if main_cmd not in SUBCOMMAND_RULES:
        return None

    rules = SUBCOMMAND_RULES[main_cmd]

    # 禁止的子命令
    if sub and sub in rules.get("forbidden", set()):
        return "forbidden"
    # 安全的子命令
    if sub and sub in rules.get("safe", set()):
        return "safe"
    # 需确认的子命令
    if sub and sub in rules.get("confirm", set()):
        return "confirm"

    # crontab 无参数时默认禁止（等同于 crontab，会进入交互模式）
    if main_cmd == "crontab" and sub is None:
        return "forbidden"
    # nc 默认 forbid（无子命令），但由通用逻辑降为 confirm 处理
    if main_cmd == "nc" and sub is None:
        return "confirm"
    # npx 默认需确认
    if main_cmd == "npx":
        return "confirm"

    return None


def classify(command: str) -> str:
    """返回 'safe' | 'confirm' | 'forbidden'。"""
    cmd = command.strip()
    if not cmd:
        return "safe"

    # ── 第一层：高危正则匹配 ──
    for pattern in FORBIDDEN_PATTERNS:
        if re.search(pattern, cmd, re.IGNORECASE):
            return "forbidden"

    # ── 第二层：命令链检测 ──
    # 如果一条命令里包含 ; && || |，分段检查。只要有一处是 confirm/forbidden，总体提升一级
    if _has_command_chaining(cmd):
        segments = CHAIN_PATTERN.split(cmd)
        worst = "safe"
        for seg in segments:
            seg = seg.strip()
            if not seg:
                continue
            level = _classify_single(seg)
            if level == "forbidden":
                return "forbidden"
            if level == "confirm":
                worst = "confirm"
        return worst

    return _classify_single(cmd)


def _classify_single(cmd: str) -> str:
    """分类单条命令（不含 && || ; | 连接符）。"""
    # 高危正则
    for pattern in FORBIDDEN_PATTERNS:
        if re.search(pattern, cmd, re.IGNORECASE):
            return "forbidden"

    main = _extract_main_command(cmd)
    if not main:
        return "safe"

    # 禁止命令
    if main in FORBIDDEN_COMMANDS:
        return "forbidden"

    # 子命令规则
    sub = _get_subcommand(cmd)
    sub_result = _check_subcommand(main, sub)
    if sub_result:
        return sub_result

    # dd 特殊处理：检查 of= 参数
    if main == "dd":
        of_match = re.search(r'of=(\S+)', cmd)
        if of_match:
            target = of_match.group(1)
            safe_devices = {"null", "zero", "random", "urandom"}
            if target.startswith("/dev/"):
                if target.split("/")[-1] in safe_devices:
                    return "safe"
                return "forbidden"
        return "confirm"

    # nc 特殊处理：检查 -e -c 参数
    if main == "nc":
        if re.search(r'\s-[a-z]*[ec]', cmd):
            return "forbidden"
        return "confirm"

    # 确认命令
    if main in CONFIRM_COMMANDS:
        # 有几个确认命令在某些参数下是安全的
        if main in {"pip", "pip3"} and cmd.rstrip().endswith("--version"):
            return "safe"
        if main == "sed" and not re.search(r'(?:^|\s)-i(?:\s|\.bak|$)', cmd) and "--in-place" not in cmd:
            return "safe"
        if main == "git" and sub is None:
            return "safe"
        return "confirm"

    # 安全命令
    if main in SAFE_COMMANDS:
        return "safe"

    # 未知命令 → 默认需确认
    return "confirm"


def explain(command: str) -> str:
    """返回分类原因说明。"""
    level = classify(command)
    if level == "safe":
        return "安全操作，直接执行"
    elif level == "confirm":
        main = _extract_main_command(command)
        return f"此操作 ({main}) 可能修改系统或文件，需用户确认"
    else:
        return "危险操作已被拦截"
