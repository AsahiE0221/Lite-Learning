"""Tool 注册表。所有 LLM 可调用的工具都在这里注册。"""

TOOLS = [
    {
        "name": "scan_papers",
        "description": "扫描论文目录，列出所有可用的 PDF 论文文件",
        "parameters": {},
        "category": "paper",
    },
    {
        "name": "search_paper",
        "description": "根据关键词或描述信息在论文目录中模糊搜索论文，返回匹配的文件名",
        "parameters": {"query": "搜索关键词或论文描述信息"},
        "category": "paper",
    },
    {
        "name": "load_paper",
        "description": "加载一篇论文到当前会话。可以传文件名、路径或搜索关键词",
        "parameters": {"path_or_query": "文件名、路径或搜索关键词"},
        "category": "paper",
    },
    {
        "name": "ask_paper",
        "description": "对当前已加载的论文内容提问。仅在已加载论文时可用",
        "parameters": {"question": "要问的问题"},
        "category": "paper",
    },
    {
        "name": "summary",
        "description": "生成当前论文的结构化摘要，包括研究背景、核心问题、方法、结论和意义",
        "parameters": {"extra_requirement": "额外的摘要要求（可选）"},
        "category": "paper",
    },
    {
        "name": "write_note",
        "description": "基于当前论文和讨论历史生成结构化阅读笔记，保存到 notes/ 目录",
        "parameters": {},
        "category": "note",
    },
    {
        "name": "compact",
        "description": "压缩对话历史，用 LLM 总结旧对话以释放上下文空间",
        "parameters": {},
        "category": "system",
    },
    {
        "name": "status",
        "description": "查看当前会话状态：已加载论文、对话轮数等",
        "parameters": {},
        "category": "system",
    },
    {
        "name": "run_command",
        "description": "在终端执行命令。读操作直接执行，写操作需用户确认",
        "parameters": {"command": "要执行的 shell 命令"},
        "category": "system",
    },
    {
        "name": "search_knowledge",
        "description": "在本地知识库中语义搜索相关论文片段。输入查询关键词或描述，返回最相关的论文段落",
        "parameters": {"query": "搜索查询，可以是关键词、短句或问题描述"},
        "category": "knowledge",
    },
    {
        "name": "index_paper",
        "description": "将当前已加载的论文索引到本地知识库，以便后续跨论文搜索",
        "parameters": {},
        "category": "knowledge",
    },
    {
        "name": "list_indexed",
        "description": "列出知识库中已索引的所有论文",
        "parameters": {},
        "category": "knowledge",
    },
]


def get_tool_by_name(name: str) -> dict | None:
    for tool in TOOLS:
        if tool["name"] == name:
            return tool
    return None


def build_tools_prompt() -> str:
    lines = ["【可用工具列表】"]
    for tool in TOOLS:
        params = ", ".join(tool["parameters"]) if tool["parameters"] else "无"
        lines.append(
            f"- {tool['name']}: {tool['description']}。参数：{params}"
        )
    return "\n".join(lines)
