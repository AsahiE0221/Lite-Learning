"""工具分发器。Handler 通过 ctx 获取依赖，不再依赖全局变量。"""
import os
import subprocess
from config import PAPERS_DIR


def dispatch(tool_name: str, args: dict, ctx: dict) -> str:
    """执行工具，ctx 需包含 session, papers, conversation, context, llm 等模块。"""
    handler = _HANDLERS.get(tool_name)
    if handler is None:
        return f"❌ 工具不存在: {tool_name}"
    try:
        return handler(args, ctx)
    except Exception as e:
        return f"❌ 执行工具 {tool_name} 失败: {e}"


# ── 各 Handler ──

def _scan_papers_handler(args: dict, ctx: dict) -> str:
    papers = ctx["papers"]
    session = ctx["session"]
    session.paper_files = papers.scan_papers(session.papers_dir)
    if not session.paper_files:
        return f"在 {session.papers_dir} 下没有找到 PDF 文件"
    lines = [f"📂 {session.papers_dir} ({len(session.paper_files)} 篇):"]
    for i, name in enumerate(session.paper_files, 1):
        lines.append(f"  [{i}] {name}")
    return "\n".join(lines)


def _search_paper_handler(args: dict, ctx: dict) -> str:
    session = ctx["session"]
    llm_client = ctx["llm"]
    query = args.get("query", "")

    if not session.paper_files:
        return "尚未扫描论文目录，请先调用 scan_papers。"

    from prompts import SEARCH_TASK
    from llm.client import chat

    file_list = "\n".join(
        f"[{i}] {name}" for i, name in enumerate(session.paper_files)
    )
    prompt = SEARCH_TASK.format(query=query, file_list=file_list)
    result = chat([{"role": "user", "content": prompt}]).strip()

    if result == "无匹配":
        return f"未找到与 \"{query}\" 匹配的论文。"

    if result in session.paper_files:
        return f"匹配到: {result}"
    for f in session.paper_files:
        if result in f or f in result:
            return f"匹配到: {f}"
    return f"未找到与 \"{query}\" 匹配的论文。"


def _load_paper_handler(args: dict, ctx: dict) -> str:
    papers = ctx["papers"]
    session = ctx["session"]
    path_or_query = args.get("path_or_query", "")

    if not path_or_query:
        return "请指定要加载的论文路径或文件名。"

    pdf_path = path_or_query
    if not pdf_path.startswith("/") and not pdf_path.startswith("~"):
        pdf_path = str(PAPERS_DIR / pdf_path)

    result = papers.load_paper(pdf_path)

    if "error" in result:
        # 尝试模糊搜索
        if not session.paper_files:
            papers_dir = session.papers_dir
            session.paper_files = papers.scan_papers(papers_dir)
        if session.paper_files:
            match = _search_paper_handler(
                {"query": path_or_query}, ctx)
            if "匹配到:" in match:
                matched_name = match.split("匹配到: ", 1)[1].strip()
                matched_path = str(PAPERS_DIR / matched_name)
                result = papers.load_paper(matched_path)
                if "error" in result:
                    return f"加载失败: {result['error']}"
            else:
                return f"加载失败: {result['error']}"
        else:
            return f"加载失败: {result['error']}"

    session.paper_title = result["title"]
    session.paper_text = result["text"]
    session.paper_pages = result["pages"]
    session.history = []
    session.total_rounds = 0

    preview = result["text"][:100].replace("\n", " ")
    return (
        f"✅ 已加载: {result['title']}\n"
        f"   页数: {result['pages']} | 字数: {result['word_count']}\n"
        f"   预览: {preview}......"
    )


def _ask_paper_handler(args: dict, ctx: dict) -> str:
    session = ctx["session"]
    if not session.is_paper_loaded():
        return "请先加载论文。"
    question = args.get("question", "")
    from conversation import ask
    return ask(question, session)


def _summary_handler(args: dict, ctx: dict) -> str:
    session = ctx["session"]
    if not session.is_paper_loaded():
        return "请先加载论文。"
    extra = args.get("extra_requirement", "")
    from conversation import summary_stream
    result = ""
    for chunk in summary_stream(extra if extra else None, session):
        result += chunk
    return result


def _write_note_handler(args: dict, ctx: dict) -> str:
    session = ctx["session"]
    if not session.is_paper_loaded():
        return "请先加载论文。"
    from conversation import write_note
    return write_note(session)


def _compact_handler(args: dict, ctx: dict) -> str:
    from context import compact
    return compact(ctx["session"])


def _status_handler(args: dict, ctx: dict) -> str:
    session = ctx["session"]
    lines = ["📊 会话状态", "=" * 30]
    if session.is_paper_loaded():
        lines.append(f"📄 当前论文: {session.paper_title}")
        lines.append(f"   页数: {session.paper_pages}")
    else:
        lines.append("📄 当前论文: 未加载")
    if session.paper_files:
        lines.append(f"📂 论文目录: {session.papers_dir} ({len(session.paper_files)} 篇)")
    else:
        lines.append("📂 论文目录: 未扫描")
    lines.append(f"💬 累计对话: {session.total_rounds} 轮")
    lines.append(f"📝 笔记目录: {session.notes_dir}")
    return "\n".join(lines)


def _run_command_handler(args: dict, ctx: dict) -> str:
    command = args.get("command", "")
    if not command:
        return "请提供要执行的命令。"

    from .shell_security import classify, explain

    level = classify(command)
    reason = explain(command)

    if level == "forbidden":
        return f"[禁止] {reason}: {command}"

    if level == "confirm":
        return (
            f"[需确认] {reason}\n"
            f"  命令: {command}\n"
            f"  请在终端中手动执行此命令，或回复 'y' 确认。"
        )

    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=30
        )
        output = result.stdout.strip() or result.stderr.strip()
        return output if output else "(命令执行完成，无输出)"
    except subprocess.TimeoutExpired:
        return f"命令超时 (30s): {command}"
    except FileNotFoundError:
        return f"命令未找到: {command.split()[0]}"


def _search_knowledge_handler(args: dict, ctx: dict) -> str:
    """搜索知识库。"""
    query = args.get("query", "")
    if not query:
        return "请提供搜索查询。"

    from knowledge import search_knowledge
    results = search_knowledge(query, top_k=5)
    if not results:
        return "未找到相关内容。知识库可能为空，请先使用 index_paper 索引论文。"

    lines = [f"🔍 搜索「{query}」找到 {len(results)} 个相关段落："]
    for i, r in enumerate(results, 1):
        text_preview = r["text"][:200].replace("\n", " ")
        lines.append(f"\n[{i}] {r['title']} (相关度: {r['score']:.2f})")
        lines.append(f"    {text_preview}...")
    return "\n".join(lines)


def _index_paper_handler(args: dict, ctx: dict) -> str:
    """索引当前论文到知识库。"""
    session = ctx["session"]
    if not session.is_paper_loaded():
        return "请先加载论文。"

    from knowledge import index_paper
    return index_paper(session.paper_title, session.paper_text)


def _list_indexed_handler(args: dict, ctx: dict) -> str:
    """列出已索引论文。"""
    from knowledge import kb_stats
    return kb_stats()

_HANDLERS = {
    "scan_papers": _scan_papers_handler,
    "search_paper": _search_paper_handler,
    "load_paper": _load_paper_handler,
    "ask_paper": _ask_paper_handler,
    "summary": _summary_handler,
    "write_note": _write_note_handler,
    "compact": _compact_handler,
    "status": _status_handler,
    "run_command": _run_command_handler,
    "search_knowledge": _search_knowledge_handler,
    "index_paper": _index_paper_handler,
    "list_indexed": _list_indexed_handler,
}
