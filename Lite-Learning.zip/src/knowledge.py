"""本地知识库：论文分块 + 向量索引 + 语义搜索。

纯 Python 实现，零外部依赖。基于字符 bigram 的轻量级语义匹配，
对中文论文效果不错。网络恢复后可替换为 ChromaDB。
"""
import os
import json
import re
import hashlib
from pathlib import Path
from config import GLOBAL_DIR
from collections import Counter

# ── 存储路径 ──
KB_DIR = Path(__file__).resolve().parent.parent / "knowledge_db"
CHUNKS_FILE = KB_DIR / "chunks.json"
INDEX_FILE = KB_DIR / "index.json"


def ensure_kb():
    KB_DIR.mkdir(parents=True, exist_ok=True)


# ═══════════════════════════════════════════════
# 中文文本分块
# ═══════════════════════════════════════════════

_CHUNK_SIZE = 500   # 字符数
_OVERLAP = 100      # 重叠字符数


def chunk_text(text: str, title: str, chunk_size: int = _CHUNK_SIZE,
               overlap: int = _OVERLAP) -> list[dict]:
    """将论文文本切分为重叠分块。按段落边界优先，保证断句完整。"""
    # 按段落分割
    paragraphs = re.split(r'\n{2,}', text.strip())
    chunks = []
    current = ""
    chunk_idx = 0

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        if len(current) + len(para) <= chunk_size:
            current += para + "\n\n"
        else:
            # 保存当前块
            if current.strip():
                chunks.append({
                    "id": _chunk_id(title, chunk_idx),
                    "title": title,
                    "index": chunk_idx,
                    "text": current.strip(),
                })
                chunk_idx += 1
                # 重叠：保留最后 overlap 个字符
                overlap_text = current[-overlap:] if len(current) > overlap else ""
                current = overlap_text + para + "\n\n"
            else:
                # 单段超长，强制切
                for i in range(0, len(para), chunk_size - overlap):
                    sub = para[i:i + chunk_size]
                    chunks.append({
                        "id": _chunk_id(title, chunk_idx),
                        "title": title,
                        "index": chunk_idx,
                        "text": sub.strip(),
                    })
                    chunk_idx += 1
                current = ""

    # 收尾
    if current.strip():
        chunks.append({
            "id": _chunk_id(title, chunk_idx),
            "title": title,
            "index": chunk_idx,
            "text": current.strip(),
        })

    return chunks


def _chunk_id(title: str, idx: int) -> str:
    raw = f"{title}:{idx}"
    return hashlib.md5(raw.encode()).hexdigest()[:12]


# ═══════════════════════════════════════════════
# 字符 bigram 向量化
# ═══════════════════════════════════════════════

def _char_bigrams(text: str) -> Counter:
    """提取字符 bigram 频率。中文效果类似于词级别的 n-gram。"""
    # 清理空白
    cleaned = re.sub(r'\s+', '', text)
    bigrams = [cleaned[i:i+2] for i in range(len(cleaned) - 1)]
    return Counter(bigrams)


def _cosine_similarity(vec1: Counter, vec2: Counter) -> float:
    """两个 Counter 之间的余弦相似度。"""
    if not vec1 or not vec2:
        return 0.0

    # 计算点积
    dot = sum(vec1[k] * vec2[k] for k in vec1 if k in vec2)

    # 计算模长
    norm1 = sum(v ** 2 for v in vec1.values()) ** 0.5
    norm2 = sum(v ** 2 for v in vec2.values()) ** 0.5

    if norm1 == 0 or norm2 == 0:
        return 0.0

    return dot / (norm1 * norm2)


# ═══════════════════════════════════════════════
# 索引管理
# ═══════════════════════════════════════════════

def _load_index() -> dict:
    """加载索引：{chunk_id: {title, text, bigrams: {bg: count}}}。"""
    ensure_kb()
    if INDEX_FILE.exists():
        with open(INDEX_FILE, "r", encoding="utf-8") as f:
            raw = json.load(f)
        # 还原 Counter
        for v in raw.values():
            v["bigrams"] = Counter(v["bigrams"])
        return raw
    return {}


def _save_index(index: dict):
    """保存索引（Counter → dict 用于 JSON 序列化）。"""
    ensure_kb()
    serializable = {}
    for k, v in index.items():
        serializable[k] = {
            "title": v["title"],
            "text": v["text"],
            "bigrams": dict(v["bigrams"]),
        }
    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump(serializable, f, ensure_ascii=False, indent=2)


def _load_chunks_meta() -> list[dict]:
    """加载分块元信息。"""
    ensure_kb()
    if CHUNKS_FILE.exists():
        with open(CHUNKS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def _save_chunks_meta(chunks: list[dict]):
    ensure_kb()
    with open(CHUNKS_FILE, "w", encoding="utf-8") as f:
        json.dump(chunks, f, ensure_ascii=False, indent=2)


# ═══════════════════════════════════════════════
# 公开 API
# ═══════════════════════════════════════════════

def index_paper(title: str, text: str) -> str:
    """索引一篇论文到知识库。返回结果描述。"""
    ensure_kb()

    # 检查是否已索引
    index = _load_index()
    existing_titles = {v["title"] for v in index.values()}
    if title in existing_titles:
        return f"⚠ 论文「{title}」已在知识库中，跳过索引。"

    # 分块
    chunks = chunk_text(text, title)

    # 向量化并存入索引
    for c in chunks:
        index[c["id"]] = {
            "title": title,
            "text": c["text"],
            "bigrams": _char_bigrams(c["text"]),
        }

    _save_index(index)

    # 更新分块元信息
    meta = _load_chunks_meta()
    meta.append({
        "title": title,
        "chunk_count": len(chunks),
        "char_count": len(text),
    })
    _save_chunks_meta(meta)

    return f"✅ 已索引: {title} ({len(chunks)} 个分块, {len(text)} 字符)"


def search_knowledge(query: str, top_k: int = 5) -> list[dict]:
    """语义搜索知识库。返回最相关的分块列表。"""
    index = _load_index()
    if not index:
        return []

    query_bigrams = _char_bigrams(query)

    # 计算每个分块与查询的相似度
    scores = []
    for chunk_id, entry in index.items():
        sim = _cosine_similarity(query_bigrams, entry["bigrams"])
        if sim > 0:
            scores.append((sim, chunk_id))

    # 排序取 top_k
    scores.sort(key=lambda x: x[0], reverse=True)
    top = scores[:top_k]

    results = []
    for sim, chunk_id in top:
        entry = index[chunk_id]
        results.append({
            "title": entry["title"],
            "text": entry["text"],
            "score": round(sim, 4),
        })

    return results


def delete_paper(title: str) -> str:
    """从知识库中删除一篇论文。"""
    index = _load_index()
    to_delete = [k for k, v in index.items() if v["title"] == title]
    for k in to_delete:
        del index[k]
    _save_index(index)

    meta = _load_chunks_meta()
    meta = [m for m in meta if m["title"] != title]
    _save_chunks_meta(meta)

    return f"✅ 已从知识库移除: {title} ({len(to_delete)} 个分块)"


def list_indexed() -> list[dict]:
    """列出已索引的论文。"""
    return _load_chunks_meta()


def kb_stats() -> str:
    """知识库统计信息。"""
    meta = _load_chunks_meta()
    if not meta:
        return "📚 知识库为空，使用 /index 索引论文。"
    total_chunks = sum(m["chunk_count"] for m in meta)
    lines = [
        "📚 知识库状态",
        f"   已索引论文: {len(meta)} 篇",
        f"   总分块数: {total_chunks}",
        f"   存储位置: {KB_DIR}",
        "",
    ]
    for m in meta:
        lines.append(f"   📄 {m['title']} ({m['chunk_count']} 块, {m['char_count']} 字)")
    return "\n".join(lines)


# ═══════════════════════════════════════════════
# 自测
# ═══════════════════════════════════════════════

if __name__ == "__main__":
    # 简单自测
    test_text = "人工智能在医疗领域的应用日益广泛。深度学习模型可以辅助医生进行疾病诊断。"
    chunks = chunk_text(test_text, "测试论文")
    print(f"分块测试: {len(chunks)} 块")

    result = index_paper("测试论文", test_text * 10)
    print(f"索引测试: {result}")

    results = search_knowledge("人工智能医疗诊断")
    print(f"搜索测试: {len(results)} 条结果")
    for r in results:
        print(f"  [{r['score']:.4f}] {r['text'][:60]}...")

    print(kb_stats())

    # 清理
    delete_paper("测试论文")
    print("清理完成 ✓")
    print("knowledge.py 自测通过 ✓")
