"""LLM 调用封装。与具体供应商解耦，只暴露 chat / chat_stream 两个接口。"""
import os
from openai import OpenAI
from config import GLOBAL_DIR
from dotenv import load_dotenv

# 确保 .env 已加载
_load_done = False


def _ensure_env():
    global _load_done
    if _load_done:
        return
    global_env = GLOBAL_DIR / ".env"
    if global_env.exists():
        load_dotenv(global_env)
    _load_done = True


def _get_client():
    _ensure_env()
    return OpenAI(
        api_key=os.getenv("DEEPSEEK_API_KEY"),
        base_url=os.getenv("DEEPSEEK_BASE_URL"),
    )


MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")


def chat(messages: list[dict]) -> str:
    try:
        client = _get_client()
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"[错误] 调用 API 失败: {e}"


def chat_stream(messages: list[dict]):
    client = _get_client()
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        stream=True,
    )
    for chunk in response:
        delta = chunk.choices[0].delta
        if delta.content:
            yield delta.content
