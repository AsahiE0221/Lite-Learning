"""斜杠指令 handler。薄封装，路由到对应模块。"""
import os
from config import PAPERS_DIR


def cmd_help(args: str, session, **deps) -> str:
    lines = [
        "可用命令：",
        "  论文操作:  /papers  /load [#编号|文件名|@关键词]  /unload",
        "  论文问答:  /summary [额外要求]  /note  /retry",
        "  对话管理:  /compact  /clear",
        "  模式切换:  /strict  /expand",
        "  调试工具:  /status  /debug",
        "  系统:      /help  /quit",
    ]
    return "\n".join(lines)


def cmd_quit(args: str, session, **deps) -> str:
    return "QUIT"


def cmd_papers(args: str, session, papers, **deps) -> str:
    session.paper_files = papers.scan_papers(session.papers_dir)
    if not session.paper_files:
        return f"在 {session.papers_dir} 下没有找到 PDF 文件"
    lines = [f"📂 {session.papers_dir} ({len(session.paper_files)} 篇):"]
    for i, name in enumerate(session.paper_files, 1):
        lines.append(f"  [{i}] {name}")
    return "\n".join(lines)


def cmd_load(args: str, session, papers, **deps) -> str:
    llm_client = deps.get("llm")
    if not args:
        return (
            "请指定要加载的论文，例如:\n"
            "  /load 论文.pdf     — 按文件名加载\n"
            "  /load #1           — 按编号加载\n"
            "  /load @关键词       — 模糊搜索加载\n"
            "  提示: 先运行 /papers 查看可用论文"
        )

    arg = args.strip()

    # 按编号加载
    if arg.startswith("#"):
        if not session.paper_files:
            return "尚未扫描论文目录，请先运行 /papers"
        try:
            num = int(arg[1:])
        except ValueError:
            return "无效的编号格式，请输入数字，例如: /load #1"
        if 1 <= num <= len(session.paper_files):
            pdf_path = os.path.join(session.papers_dir, session.paper_files[num - 1])
            return _do_load(pdf_path, session, papers)
        else:
            return f"无效编号，可用范围: 1 ~ {len(session.paper_files)}"

    # 模糊搜索
    if arg.startswith("@"):
        if not session.paper_files:
            return "尚未扫描论文目录，请先运行 /papers"
        query = arg[1:].strip()
        if not query:
            return "请提供搜索关键词，例如: /load @安倍"

        from prompts import SEARCH_TASK
        from llm.client import chat

        file_list = "\n".join(
            f"[{i}] {name}" for i, name in enumerate(session.paper_files)
        )
        prompt = SEARCH_TASK.format(query=query, file_list=file_list)
        match = chat([{"role": "user", "content": prompt}]).strip()
        if match == "无匹配":
            return f'没有找到与 "{query}" 匹配的论文'
        if match not in session.paper_files:
            for f in session.paper_files:
                if match in f or f in match:
                    match = f
                    break
            else:
                return f'没有找到与 "{query}" 匹配的论文'
        return f"🔍 匹配到: {match}\n{_do_load(os.path.join(session.papers_dir, match), session, papers)}"

    # 按文件名/路径加载
    return _do_load(arg, session, papers)


def _do_load(pdf_path: str, session, papers) -> str:
    result = papers.load_paper(pdf_path)
    if "error" in result:
        return f"加载失败: {result['error']}"

    session.paper_title = result["title"]
    session.paper_text = result["text"]
    session.paper_pages = result["pages"]
    session.history = []
    session.total_rounds = 0

    preview = result["text"][:100].replace("\n", " ")
    return (
        f"✅ 已加载: {result['title']}\n"
        f"   页数: {result['pages']} | 字数: {result['word_count']}\n"
        f"   预览: {preview}......"
    )


def cmd_summary(args: str, session, **deps) -> str:
    if not session.is_paper_loaded():
        yield "请先使用 /load 加载论文。"
        return
    from conversation import summary_stream
    extra = args.strip() if args else None
    for chunk in summary_stream(extra, session):
        yield chunk


def cmd_note(args: str, session, **deps):
    if not session.is_paper_loaded():
        yield "请先使用 /load 加载论文。"
        return
    from conversation import write_note_stream
    yield from write_note_stream(session)


def cmd_status(args: str, session, **deps) -> str:
    lines = ["📊 会话状态", "=" * 30]
    if session.is_paper_loaded():
        lines.append(f"📄 当前论文: {session.paper_title}")
        lines.append(f"   页数: {session.paper_pages}")
    else:
        lines.append("📄 当前论文: 未加载")
    if session.paper_files:
        lines.append(f"📂 论文目录: {session.papers_dir} ({len(session.paper_files)} 篇)")
    else:
        lines.append("📂 论文目录: 未扫描")
    lines.append(f"💬 累计对话: {session.total_rounds} 轮")
    mode = "🔒 严格模式" if session.strict_mode else "🔓 拓展模式"
    lines.append(f"🎯 {mode}")
    lines.append(f"📝 笔记目录: {session.notes_dir}")
    return "\n".join(lines)


def cmd_compact(args: str, session, **deps) -> str:
    from context import compact
    return compact(session)


def cmd_clear(args: str, session, react_agent, **deps) -> str:
    from context import clear
    react_agent.reset_messages()
    return clear(session)


def cmd_unload(args: str, session, react_agent, **deps) -> str:
    session.paper_title = None
    session.paper_text = None
    session.paper_pages = None
    session.history = []
    session.chat_history = []
    session.total_rounds = 0
    react_agent.reset_messages()
    return "✅ 论文已卸载。"


def cmd_strict(args: str, session, **deps) -> str:
    session.strict_mode = True
    return "🔒 已切换为严格模式（回答仅限论文原文）。"


def cmd_expand(args: str, session, **deps) -> str:
    session.strict_mode = False
    return "🔓 已切换为拓展模式（可结合外部知识并标注来源）。"


def cmd_debug(args: str, session, **deps) -> str:
    session.debug_mode = not session.debug_mode
    state = "开启" if session.debug_mode else "关闭"
    return f"🔍 调试模式已{state}"


def cmd_retry(args: str, session, react_agent, **deps):
    from context import retry_stream
    yield from retry_stream(session)

# ═══════════════════════════════════════════════
# 知识库命令
# ═══════════════════════════════════════════════

def cmd_index(args: str, session, **deps) -> str:
    """将当前论文索引到知识库。"""
    if not session.is_paper_loaded():
        return "请先使用 /load 加载论文。"
    from knowledge import index_paper
    return index_paper(session.paper_title, session.paper_text)


def cmd_search(args: str, session, **deps) -> str:
    """在知识库中搜索。"""
    query = args.strip()
    if not query:
        return "请提供搜索关键词，例如: /search 政教分离"
    from knowledge import search_knowledge
    results = search_knowledge(query, top_k=5)
    if not results:
        return "未找到相关内容（知识库为空或无可匹配结果）"
    lines = [f"🔍 搜索「{query}」找到 {len(results)} 个相关段落："]
    for i, r in enumerate(results, 1):
        lines.append("")
        lines.append(f"[{i}] 📄 {r['title']}  (相关度: {r['score']:.2f})")
        lines.append(f"    {r['text'][:300]}...")
    return "\n".join(lines)


def cmd_kb(args: str, session, **deps) -> str:
    """查看知识库状态。"""
    from knowledge import kb_stats
    return kb_stats()
