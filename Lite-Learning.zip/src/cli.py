"""CLI 入口：初始化模块 → 接线 → TUI 主循环。"""
from time import sleep
from pathlib import Path
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.history import FileHistory
from prompt_toolkit.styles import Style

from config import PAPERS_DIR, NOTES_DIR, HISTORY_FILE, ensure_dirs
from session import Session
import papers as papers_mod
from react import ReActAgent
import commands as cmds


# ═══════════════════════════════════════════════
# 命令注册表
# ═══════════════════════════════════════════════

COMMANDS = [
    {"name": "/help",    "handler": cmds.cmd_help,    "exact": True,  "hidden": False},
    {"name": "/quit",    "handler": cmds.cmd_quit,    "exact": True,  "hidden": False},
    {"name": "/papers",  "handler": cmds.cmd_papers,  "exact": True,  "hidden": False},
    {"name": "/load",    "handler": cmds.cmd_load,    "exact": False, "hidden": False},
    {"name": "/summary", "handler": cmds.cmd_summary, "exact": False, "hidden": False},
    {"name": "/note",    "handler": cmds.cmd_note,    "exact": True,  "hidden": False},
    {"name": "/status",  "handler": cmds.cmd_status,  "exact": True,  "hidden": False},
    {"name": "/compact", "handler": cmds.cmd_compact, "exact": True,  "hidden": False},
    {"name": "/strict",  "handler": cmds.cmd_strict,  "exact": True,  "hidden": False},
    {"name": "/expand",  "handler": cmds.cmd_expand,  "exact": True,  "hidden": False},
    {"name": "/debug",   "handler": cmds.cmd_debug,   "exact": True,  "hidden": False},
    {"name": "/retry",   "handler": cmds.cmd_retry,   "exact": True,  "hidden": False},
    {"name": "/clear",   "handler": cmds.cmd_clear,   "exact": True,  "hidden": False},
    {"name": "/index",   "handler": cmds.cmd_index,   "exact": True,  "hidden": False},
    {"name": "/search",  "handler": cmds.cmd_search,  "exact": False, "hidden": False},
    {"name": "/kb",      "handler": cmds.cmd_kb,      "exact": True,  "hidden": False},
    {"name": "/unload",  "handler": cmds.cmd_unload,  "exact": True,  "hidden": False},
]


def _dispatch_command(user_input: str, session, react_agent, **deps):
    """路由：匹配命令 → 调 handler。"""
    for cmd in COMMANDS:
        if cmd["exact"] and user_input == cmd["name"]:
            return cmd["handler"](args="", session=session, react_agent=react_agent, **deps)
        if not cmd["exact"] and (
            user_input == cmd["name"] or user_input.startswith(cmd["name"] + " ")
        ):
            args = user_input[len(cmd["name"]):].strip()
            return cmd["handler"](args=args, session=session, react_agent=react_agent, **deps)
    if user_input.startswith("/"):
        return f"未知命令: {user_input}，输入 /help 查看可用命令。"
    return None


# ═══════════════════════════════════════════════
# TUI 组件
# ═══════════════════════════════════════════════

def _build_completer(session):
    words = set()
    for cmd in COMMANDS:
        if cmd.get("hidden"):
            continue
        words.add(cmd["name"])
        if not cmd["exact"]:
            words.add(cmd["name"] + " ")
    for f in session.paper_files:
        words.add(f)
    return WordCompleter(sorted(words), ignore_case=True, sentence=True)


def _bottom_toolbar():
    def toolbar():
        mode_icon = "🔒" if session.strict_mode else "🔓"
        mode_name = "strict" if session.strict_mode else "expand"
        debug = " | 🐛 debug" if session.debug_mode else ""
        if session.is_paper_loaded():
            paper_info = f"📄 {session.paper_title[:30]}"
        else:
            paper_info = "📄 未加载"
        rounds = session.total_rounds
        return f" {mode_icon} {mode_name} | {paper_info} | 💬 {rounds}轮{debug} | Tab 补全 | Ctrl+D 退出 "
    return toolbar


STYLE = Style.from_dict({
    "prompt": "bold #00aa00",
    "toolbar": "bg:#333333 #ffffff",
})


# ═══════════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════════

def main():
    global session
    ensure_dirs()

    # 初始化各模块
    session = Session(
        papers_dir=str(PAPERS_DIR),
        notes_dir=str(NOTES_DIR),
    )

    ctx = {
        "session": session,
        "papers": papers_mod,
        "llm": __import__("llm.client", fromlist=["client"]),
    }
    react = ReActAgent(ctx)

    deps = {
        "papers": papers_mod,
        "llm": ctx["llm"],
    }

    print("📚 Lite-learning v0.4 — 论文阅读助手")
    print("输入 /help 查看可用命令，Tab 补全，Ctrl+D 退出\n")

    history = FileHistory(str(HISTORY_FILE))

    while True:
        try:
            user_input = prompt(
                [("class:prompt", "📄 ")],
                completer=_build_completer(session),
                history=history,
                bottom_toolbar=_bottom_toolbar(),
                style=STYLE,
                refresh_interval=0.5,
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋 再见！")
            break

        if not user_input:
            continue

        # 斜杠指令
        if user_input.startswith("/"):
            result = _dispatch_command(user_input, session, react, **deps)
            if result == "QUIT":
                print("👋 再见！")
                break
            if hasattr(result, "__iter__") and not isinstance(result, str):
                print("🤖 ", end="", flush=True)
                for chunk in result:
                    print(chunk, end="", flush=True)
                    sleep(0.02)
                print()
            else:
                print(result)

        # 自然语言 → ReAct
        else:
            print("🤖 ", end="", flush=True)
            for chunk in react.run(user_input):
                print(chunk, end="", flush=True)
                sleep(0.02)
            print()


if __name__ == "__main__":
    main()
