"""会话状态。纯数据容器，所有模块通过它感知彼此的状态变更。"""
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Session:
    paper_title: str | None = None
    paper_text: str | None = None
    paper_pages: int | None = None
    history: list[dict] = field(default_factory=list)        # 论文问答历史
    chat_history: list[dict] = field(default_factory=list)    # 自由对话历史
    strict_mode: bool = True
    total_rounds: int = 0
    paper_files: list[str] = field(default_factory=list)
    debug_mode: bool = False

    papers_dir: str = ""
    notes_dir: str = ""

    def is_paper_loaded(self) -> bool:
        return self.paper_title is not None and self.paper_text is not None

    @property
    def mode_label(self) -> str:
        return "严格模式" if self.strict_mode else "拓展模式"
