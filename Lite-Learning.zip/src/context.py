"""对话历史管理：压缩、清除、重试。"""
from llm.client import chat
from prompts import COMPACT_PAPER_TASK, COMPACT_CHAT_TASK


def compact(session) -> str:
    """压缩对话历史：用 LLM 总结旧对话替代原始消息。"""
    total_messages = len(session.history) + len(session.chat_history)
    if total_messages < 10:
        return "对话历史较短（不足 5 轮），暂不需要压缩。"

    messages_compressed = 0

    if len(session.history) >= 10:
        history_text = ""
        for msg in session.history:
            role = "用户" if msg["role"] == "user" else "助手"
            history_text += f"[{role}]: {msg['content']}\n\n"

        prompt = COMPACT_PAPER_TASK.format(history_text=history_text)
        summary = chat([{"role": "user", "content": prompt}])
        messages_compressed += len(session.history)
        session.history = [
            {"role": "user", "content": f"[对话历史摘要] {summary}"}
        ]

    if len(session.chat_history) >= 10:
        history_text = ""
        for msg in session.chat_history:
            role = "用户" if msg["role"] == "user" else "助手"
            history_text += f"[{role}]: {msg['content']}\n\n"

        prompt = COMPACT_CHAT_TASK.format(history_text=history_text)
        summary = chat([{"role": "user", "content": prompt}])
        messages_compressed += len(session.chat_history)
        session.chat_history = [
            {"role": "user", "content": f"[对话历史摘要] {summary}"}
        ]

    return (
        f"✅ 对话已压缩: {messages_compressed} 条消息 → 摘要\n"
        f"   论文对话: {len(session.history)} 条 | 自由对话: {len(session.chat_history)} 条"
    )


def clear(session) -> str:
    session.history = []
    session.chat_history = []
    session.total_rounds = 0
    # react messages 由调用方（react.py）自行管理
    return "✅ 对话历史已清除。"


def retry(session) -> str:
    """重新生成上一轮回答。"""
    if not session.history:
        return "没有可重试的对话。"

    last_user = None
    for msg in reversed(session.history):
        if msg["role"] == "user":
            last_user = msg["content"]
            break
    if last_user is None:
        return "没有可重试的问题。"

    # 移除最后一轮 Q&A
    if len(session.history) >= 2:
        session.history = session.history[:-2]

    # 从 user content 中提取原始问题
    # 格式是 "【当前模式：...】\n【论文标题】...\n【论文全文】...\n【用户问题】xxx"
    parts = last_user.split("【用户问题】")
    question = parts[-1].strip() if len(parts) > 1 else last_user

    from conversation import ask
    return ask(question, session)


def retry_stream(session):
    """流式重新生成上一轮回答。"""
    if not session.history:
        yield "没有可重试的对话。"
        return

    last_user = None
    for msg in reversed(session.history):
        if msg["role"] == "user":
            last_user = msg["content"]
            break
    if last_user is None:
        yield "没有可重试的问题。"
        return

    # 移除最后一轮 Q&A
    if len(session.history) >= 2:
        session.history = session.history[:-2]

    # 提取原始问题
    parts = last_user.split("【用户问题】")
    question = parts[-1].strip() if len(parts) > 1 else last_user

    from conversation import ask_stream
    yield from ask_stream(question, session)
