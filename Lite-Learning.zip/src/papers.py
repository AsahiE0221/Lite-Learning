"""论文管理：扫描、搜索、加载。纯函数，不持有会话状态。"""
import os
from skills.pdf_reader import extract


def scan_papers(papers_dir: str) -> list[str]:
    """扫描论文目录，返回 PDF 文件名列表。"""
    if not os.path.isdir(papers_dir):
        return []
    return sorted([
        f for f in os.listdir(papers_dir)
        if f.lower().endswith(".pdf")
    ])


def load_paper(pdf_path: str) -> dict:
    """加载单篇论文，返回 {title, text, pages, word_count} 或 {error}。"""
    if not pdf_path.startswith("/") and not pdf_path.startswith("~"):
        # 相对路径暂不处理，由调用方拼接
        pass
    result = extract(pdf_path)

    if "error" in result:
        return {"error": result["error"]}

    return {
        "title": result["title"],
        "text": result["text"],
        "pages": result["pages"],
        "word_count": result["word_count"],
    }
