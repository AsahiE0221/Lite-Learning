# 导入PDF阅读模块，这里使用的是PyMuPDF
import fitz


def extract(pdf_path: str) -> dict:
    """
    用于提取PDF文件的内容
    input：pdf_path表示PDF文件的路径
    output：返回一个字典，包含PDF文件的标题、内容、页数和字数
    """
    try:
        # 打开PDF文件
        doc = fitz.open(pdf_path)
    except (FileNotFoundError, RuntimeError):
        return {"error": f"文件不存在: {pdf_path}"}
    except Exception as e:
        return {"error": f"无法打开文件: {e}"}
    # 定义空的字符串，因为PyMuPDF是逐行阅读，所以用于存取每行的所有内容
    full_text = ""
        # 用遍历逐页的方式，将每页的文本内容添加到full_text中
    for page in doc:
        full_text += page.get_text()
    
    if not full_text.strip():
        return {"error": "PDF中未提取到文字，请检查后重试"}
    
    title = doc.metadata.get("title", "").strip()
    if not title:
        title = pdf_path.split("/")[-1].replace(".pdf", "")
        
    return {
        "title": title,
        "text": full_text,
        "pages": len(doc),
        "word_count": len(full_text)
    }

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("用法: python pdf_reader.py <pdf文件路径>")
        sys.exit(1)
    
    path = sys.argv[1]
    result = extract(path)

    if "error" in result:
        print(result["error"])
        sys.exit(1)

    print(f"文件标题: {result['title']}")
    print(f"文件页数: {result['pages']}")
    print(f"文件字数: {result['word_count']}")
    print(f"正文预览: {result['text'][:200]}......")