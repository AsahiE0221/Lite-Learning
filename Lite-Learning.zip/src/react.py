"""ReAct 决策循环 —— LLM 自主选择工具 → 执行 → 反馈 → 再决策。"""
import json
import re
from llm.client import chat, chat_stream
from tools.registry import TOOLS, build_tools_prompt, get_tool_by_name
from tools.handlers import dispatch
from prompts import SYSTEM_PROMPT, REACT_FORMAT_RULES, REACT_DECISION_RULES


def build_system_prompt() -> str:
    """组装 ReAct system prompt：全静态，命中 LLM 缓存。"""
    tools_text = build_tools_prompt()
    return "\n".join([
        SYSTEM_PROMPT,
        tools_text,
        REACT_FORMAT_RULES,
        REACT_DECISION_RULES,
        "\n【内容规则 — 见上方 SYSTEM_PROMPT 中的模式规则】",
    ])


def _build_user_message(user_input: str, session) -> str:
    """拼装 user message：动态信息放在这里，不影响 system prompt 缓存。"""
    if session.is_paper_loaded():
        paper_status = f"已加载: {session.paper_title} ({session.paper_pages}页)"
    else:
        paper_status = "未加载论文"

    papers_count = len(session.paper_files) if session.paper_files else "未扫描"

    parts = [
        f"【当前模式：{session.mode_label}】",
        f"【会话状态】论文: {paper_status} | 可用论文数量: {papers_count}",
        f"【用户输入】{user_input}",
    ]
    return "\n".join(parts)


def _parse_decision(raw: str) -> dict | None:
    """从 LLM 原始回复中提取 JSON 决策。"""
    text = raw.strip()

    # 方案 1：纯 JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # 方案 2：```json ... ``` 代码块
    match = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # 方案 3：文本中第一个 {...}
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except json.JSONDecodeError:
            pass

    return None


class ReActAgent:
    """ReAct 决策循环。通过 ctx 获取所有依赖。"""

    def __init__(self, ctx: dict):
        self.ctx = ctx
        self.messages: list[dict] = []
        self.max_iterations = 10

    @property
    def session(self):
        return self.ctx["session"]

    def _is_tool_available(self, tool_name: str) -> bool:
        return get_tool_by_name(tool_name) is not None

    def reset_messages(self):
        self.messages = []

    def run(self, user_input: str):
        """执行 ReAct 决策循环。返回生成器，逐块输出文字。"""
        system_prompt = build_system_prompt()
        user_msg = _build_user_message(user_input, self.session)

        # 首次调用或加载了新论文 → 重新开始
        if not self.messages or not self.session.is_paper_loaded():
            self.messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_msg},
            ]
        else:
            # 保留历史，更新 system prompt 追加新问题
            self.messages[0] = {"role": "system", "content": system_prompt}
            self.messages.append({"role": "user", "content": user_msg})

        for iteration in range(self.max_iterations):
            if self.session.debug_mode:
                yield f"\n{'─' * 30}\n[DEBUG] 第 {iteration + 1} 轮决策\n"

            # 流式调用 LLM，debug 模式下实时输出给用户
            raw = ""
            if self.session.debug_mode:
                yield "[DEBUG] LLM 思考中..."
            for chunk in chat_stream(self.messages):
                raw += chunk
                if self.session.debug_mode:
                    yield chunk

            if self.session.debug_mode:
                preview = raw[:200] + ("..." if len(raw) > 200 else "")
                yield f"[DEBUG] LLM 返回: {preview}\n"

            decision = _parse_decision(raw)
            if decision is None:
                if self.session.debug_mode:
                    yield f"[DEBUG] JSON 解析失败，当作文本输出\n{'─' * 30}\n\n"
                yield raw
                return

            action = decision.get("action")

            if action == "answer":
                if self.session.debug_mode:
                    yield f"[DEBUG] 决策: 直接回答\n{'─' * 30}\n\n"
                content = decision.get("content", "")
                self.session.total_rounds += 1
                yield from content  # 逐个字符输出
                return

            # 调用工具
            if not self._is_tool_available(action):
                available = [t["name"] for t in TOOLS]
                error_msg = f"工具 {action} 不存在，可用工具: {available}"
                self.messages.append({"role": "assistant", "content": raw})
                self.messages.append({"role": "system", "content": error_msg})
                if self.session.debug_mode:
                    yield f"[DEBUG] {error_msg}\n"
                continue

            args = decision.get("args", {})
            if self.session.debug_mode:
                yield f"[DEBUG] 调用: {action}({args})\n"

            result = dispatch(action, args, self.ctx)
            if self.session.debug_mode:
                preview = result[:200] + ("..." if len(result) > 200 else "")
                yield f"[DEBUG] 返回: {preview}\n"

            self.messages.append({"role": "assistant", "content": raw})
            self.messages.append(
                {"role": "system", "content": f"工具 {action} 返回结果:\n{result}"}
            )

        yield "\n(已达到最大决策轮次，请简化你的问题)"
